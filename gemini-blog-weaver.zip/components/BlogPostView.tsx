import React from 'react';
import { BlogPost } from '../types';
import { ArrowLeftIcon, ImagePlaceholderIcon } from './icons';

interface BlogPostViewProps {
  post: BlogPost;
  onBack: () => void;
}

export const BlogPostView: React.FC<BlogPostViewProps> = ({ post, onBack }) => {
  return (
    <article className="bg-white p-6 sm:p-8 md:p-10 rounded-xl shadow-xl max-w-4xl mx-auto">
      <button
        onClick={onBack}
        className="mb-8 inline-flex items-center text-sky-600 hover:text-sky-800 transition-colors font-medium group"
        aria-label="Go back to posts list"
      >
        <ArrowLeftIcon className="w-5 h-5 mr-2 transition-transform group-hover:-translate-x-1" />
        Back to Posts
      </button>

      {post.imageUrl ? (
        <img 
          src={post.imageUrl} 
          alt={`Main image for ${post.title}`} 
          className="w-full h-auto max-h-96 object-cover rounded-lg mb-8 shadow-md"
        />
      ) : (
        <div className="w-full h-64 bg-slate-200 flex items-center justify-center text-slate-400 rounded-lg mb-8 shadow-inner">
          <ImagePlaceholderIcon className="w-24 h-24" />
        </div>
      )}

      <header className="mb-6 border-b border-slate-200 pb-6">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-800 leading-tight">
          {post.title}
        </h1>
        <p className="text-slate-500 mt-3 text-sm md:text-base">{post.date}</p>
      </header>
      <div 
        className="prose prose-slate prose-lg max-w-none break-words whitespace-pre-line text-slate-700"
      >
        {post.content}
      </div>
    </article>
  );
};