import React from 'react';
import { BlogPost } from '../types';
import { ArrowRightIcon, ImagePlaceholderIcon } from './icons';

interface BlogPostCardProps {
  post: BlogPost;
  onSelect: (post: BlogPost) => void;
}

export const BlogPostCard: React.FC<BlogPostCardProps> = ({ post, onSelect }) => {
  return (
    <article 
      className="bg-white rounded-xl shadow-lg overflow-hidden transform transition-all hover:shadow-2xl hover:-translate-y-1 flex flex-col cursor-pointer h-full group"
      onClick={() => onSelect(post)}
      tabIndex={0}
      onKeyPress={(e) => e.key === 'Enter' && onSelect(post)}
      aria-labelledby={`post-title-${post.id}`}
    >
      {post.imageUrl ? (
        <img 
            src={post.imageUrl} 
            alt={`Visual representation for ${post.title}`}
            className="w-full h-48 object-cover group-hover:opacity-90 transition-opacity" 
        />
      ) : (
        <div className="w-full h-48 bg-slate-200 flex items-center justify-center text-slate-400 group-hover:bg-slate-300 transition-colors">
          <ImagePlaceholderIcon className="w-16 h-16" />
        </div>
      )}
      <div className="p-6 flex flex-col flex-grow">
        <header className="mb-4">
          <h2 id={`post-title-${post.id}`} className="text-xl sm:text-2xl font-semibold text-sky-700 group-hover:text-sky-600 transition-colors">
            {post.title}
          </h2>
          <p className="text-xs text-slate-500 mt-1">{post.date}</p>
        </header>
        <div className="text-slate-600 text-sm leading-relaxed mb-4 flex-grow">
          <p>{post.excerpt}</p>
        </div>
        <footer className="mt-auto">
          <span className="inline-flex items-center text-sky-600 font-medium group-hover:text-sky-500 transition-colors">
            Read more
            <ArrowRightIcon className="ml-2 w-4 h-4" />
          </span>
        </footer>
      </div>
    </article>
  );
};