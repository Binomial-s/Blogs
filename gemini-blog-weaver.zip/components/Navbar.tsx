
import React from 'react';
import { FeatherIcon } from './icons'; // A simple feather icon for branding

export const Navbar: React.FC = () => {
  return (
    <nav className="bg-gradient-to-r from-sky-600 to-cyan-500 shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <FeatherIcon className="h-10 w-10 text-white mr-3" />
            <span className="font-bold text-3xl text-white tracking-tight">
              Gemini Blog Weaver
            </span>
          </div>
          {/* Future Nav items could go here */}
        </div>
      </div>
    </nav>
  );
};
